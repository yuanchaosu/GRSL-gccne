function classification_map_rgb=giveColorWHU(classTest,m,n)
colorList = [0, 255, 0;
    100, 100, 0; 
    40, 135, 100; 
    0, 120, 0; 
    160, 90, 50; 
    0, 155, 255;
    155, 155, 155; 
    216, 191, 216; 
    255, 0, 130; 
    255,255,255;
    0,0,0];
classification_map_rgb = reshape(colorList(classTest,:),m,n,[]);
end


