% The purpose of this demo is to conduct academic communication. 
% The demo may not be commercialized without the permission of the developer.
% Authors: Yuanchao Su, Lianru Gao, Mengying Jiang, Xu Sun, Xueer You, and Pengfei Li
% Janary.2022
% Email: suych3@xust.edu.cn (or suych3@mail2.sysu.edu.cn)
clc
clear all
close all
currentFolder = pwd;
addpath(genpath(currentFolder))
%%
% test = 1, Indian Pines dataset 
% test = 2, WHU-Hi-LongKou dataset 
test = 1;
switch test
    case 1
        load Indian.mat
        load Indian_gt.mat
        C=[10^0 10^1 10^2 10^3 10^4 10^5];
        sigma=[2^(-4),2^(-3),2^(-2),2^(-1),2^(0),2^(1),2^(2),2^(3),2^(4)];
        num_subsp = 1;
        percentum_trainsamples = 0.05;
        nclass = 16;
        run_times = 10;
        [Par] = User_setting(test);
        accuracy = 'yes';
        [pred1,subsp_feas,OA,std_OA,KAPPA,std_KAPPA,AA,std_AA,CA,std_CA] = GCCNE(image,'GT',GT,'TRAINSAMPLES',percentum_trainsamples,...
    'SUBSPACE_NUMBER',num_subsp,'CLASS_NUMBER',nclass,'RUNTIMES',run_times,'VALIDATION1',C,'VALIDATION2',sigma,'CUTTING_NUMBER',...
    Par.nCut,'SUBSPACE_DIMENSION',Par.dim_sub,'WINDOW_SIZE',Par.window_size,'USER_PARAMETER',Par.alpha, 'ACCURACY',accuracy);
    OA = OA
    stdOA = std_OA
    AA = AA
    stdAA = std_AA
    Kappa = KAPPA
    stdKappa = std_KAPPA
    CA = CA
    stdCA = std_CA
    pred1(pred1==0)=17;
    Pred_CM = giveColorIndian(pred1,145,145);
    GT2d = hyperConvert2d(GT);
    GT2d(GT2d==0)=17;
    CM = giveColorIndian(GT2d,145,145);
    figure;
    subplot(1,2,1)
    imshow(uint8(CM));
    title ('Ground Truth')
    subplot(1,2,2)
    imshow(uint8(Pred_CM));
    title ('GCCNE')
    case 2
        load WHU_Hi_LongKou
        load WHU_Hi_LongKou_gt
         C=[10^0 10^1 10^2 10^3 10^4 10^5];
         sigma=[2^(-4),2^(-3),2^(-2),2^(-1),2^(0),2^(1),2^(2),2^(3),2^(4)];
         num_subsp = 6;
         percentum_trainsamples = 0.01;
         nclass = 9;
         run_times = 10;
         [Par] = User_setting(test);
         accuracy = 'yes';
         [pred1,subsp_feas,OA,std_OA,KAPPA,std_KAPPA,AA,std_AA,CA,std_CA] = GCCNE(WHU_Hi_LongKou,'GT',WHU_Hi_LongKou_gt,'TRAINSAMPLES',percentum_trainsamples,...
    'SUBSPACE_NUMBER',num_subsp,'CLASS_NUMBER',nclass,'RUNTIMES',run_times,'VALIDATION1',C,'VALIDATION2',sigma,'CUTTING_NUMBER',...
    Par.nCut,'SUBSPACE_DIMENSION',Par.dim_sub,'WINDOW_SIZE',Par.window_size,'USER_PARAMETER',Par.alpha, 'ACCURACY',accuracy);
    OA = OA
    stdOA = std_OA
    AA = AA
    stdAA = std_AA
    Kappa = KAPPA
    stdKappa = std_KAPPA
    CA = CA
    stdCA = std_CA
    GT2d = hyperConvert2d(WHU_Hi_LongKou_gt);
    GT2d(GT2d==0)=10;
    CM = giveColorWHU(GT2d,550,400);
    figure;
    subplot(1,2,1)
    imshow(uint8(CM));
    title ('Ground Truth')
    pred1(pred1==0)=10;
    Pred_CM = giveColorWHU(pred1,550,400);
    subplot(1,2,2)
    imshow(uint8(Pred_CM));
    title ('GCCNE')
end
