function classification_map_rgb=giveColorIndian(classTest,m,n)
colorList = [0, 255, 0;
    100, 100, 0; 
    40, 135, 100; 
    0, 120, 0; 
    160, 90, 50; 
    0, 155, 255;
    155, 155, 155; 
    216, 191, 216; 
    255, 0, 130; 
    139, 0, 0; 
    0, 50, 255;
    255, 0, 0; 
    238, 154, 0; 
    85, 20, 139;
    255, 127, 80;
    20,0,205; 
    255,255,255;
    0,0,0];
classification_map_rgb = reshape(colorList(classTest,:),m,n,[]);
end


