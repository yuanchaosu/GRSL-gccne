# The purpose of this demo is to conduct academic communication. 
# All source codes will be published after the paper is accepted.
#
# ----------------------------------------------------------------------------------------
# The demo is used for displaying GCCNE.
# Title: "Graph-Cut-Based Collaborative Node Embeddings for Hyperspectral Images Classification"
#
# ----------------------------------------------------------------------------------------
# Authors: Yuanchao Su, Lianru Gao, Mengying Jiang, Xu Sun, Xueer You, and Pengfei Li
# Recommendation：Please use MATLAB 2020 or later version to run the demo.
# RAM: 16GB
#
# ----------------------------------------------------------------------------------------
# The purpose of this license is to make an operation manual, and the purpose of this demo
# is to conduct academic communication. Copyright of the system development department. 
# The demo may not be commercialized without the permission of the developer.
#
# Janary.2022