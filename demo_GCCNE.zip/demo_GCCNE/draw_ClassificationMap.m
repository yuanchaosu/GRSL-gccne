clc;
clear all;
close;
currentFolder = pwd;
addpath(genpath(currentFolder))
%draw ground truth
TR = double(imread('IndianTR123_temp123.tif'));
TE = double(imread('IndianTE123_temp123.tif'));
[m, n] = size(TR);

GT = TR + TE;
GT2d = hyperConvert2d(GT);
GT2d(GT2d==0)=17;
CM = giveColorCM_HH(GT2d,m,n);
figure;
imshow(uint8(CM));

% draw predicted classificaiton map
load features.mat;

TE2d = hyperConvert2d(TE);
x = find(TE2d > 0);
Pred_TE = zeros(size(TE2d));
%GCN
% features_t=features(696:10366,:);
%miniGCN,2DCNN
 features_t=features;
[~, ind] = max(features_t', [], 1);
Pred_TE(:, x) = ind;
Pred_TE3d = hyperConvert3d(Pred_TE, m, n);

Pred_CM = TR + Pred_TE3d;
Pred_CM(Pred_CM==0)=17;
Pred_CM = giveColorCM_HH(Pred_CM,m,n);
figure;
imshow(uint8(Pred_CM));

testIndexs=find(TE2d>0);
testLabels=TE2d(TE2d>0);

AA1=zeros(10,1);
OA1=zeros(10,1);
KAPPA1=zeros(10,1);
CA1=zeros(16,10);
TstTime=zeros(10,1);
TrnTime=zeros(10,1);
SchTime=zeros(10,1);
zeros(10,1);   
tstart = tic;
for j=1:10
      %--------------------------计算精度------------------------------------------------------%
    pred=zeros(145,145);
    pred(testIndexs)=ind;
    [OA,kappa,AA,CA]=calcError(testLabels,pred(testIndexs), 1:16);
    OA1(j)=OA;
    AA1(j)=AA;
    KAPPA1(j)=kappa;
    CA1(:,j)=CA;
%     totaltime(j)=toc(tstart);
end
oa=mean(OA1)
stdoa=std(OA1)
aa=mean(AA1)
stdaa=std(AA1)
KAPPA=mean( KAPPA1)
stdKAPPA=std( KAPPA1)
stdca=std(CA1')
ca=mean(CA1')